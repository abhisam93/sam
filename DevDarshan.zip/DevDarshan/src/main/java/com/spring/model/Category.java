package com.spring.model;

import javax.persistence.Id;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonBackReference;
import com.fasterxml.jackson.annotation.JsonIgnore;

import javax.persistence.Entity;
import javax.persistence.Column;
import javax.persistence.OneToMany;

import java.io.Serializable;
import java.util.List;

@Entity
@Table(name="bookcategories")
public class Category implements Serializable {
	
	@Id
	private int cid;
	@Column(name="category")
	private String categoryName;
	
	@OneToMany(mappedBy="category")
	@JsonBackReference
	private List<Book> books;
	
	public List<Book> getBooks() {
		return books;
	}

	public void setBooks(List<Book> books) {
		this.books = books;
	}

	public int getCid() {
		return cid;
	}
	
	public void setCid(int cid) {
		this.cid = cid;
	}
	
	public String getCategoryName() {
		return categoryName;
	}
	
	public void setCategoryName(String categoryName) {
		this.categoryName = categoryName;
	}
	
	
}
